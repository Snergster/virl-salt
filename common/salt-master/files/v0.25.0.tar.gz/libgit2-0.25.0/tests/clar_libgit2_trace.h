#ifndef __CLAR_LIBGIT2_TRACE__
#define __CLAR_LIBGIT2_TRACE__

void cl_global_trace_register(void);
void cl_global_trace_disable(void);

#endif
